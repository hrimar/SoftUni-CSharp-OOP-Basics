﻿using System;
using System.Collections.Generic;
using System.Linq;

public class StartUp
{
    //  ОК 400/400 но с 4 част разместих 2-ра
    static void Main()
    {
        var engine = new Engine();
        engine.Run();      
    }
}

