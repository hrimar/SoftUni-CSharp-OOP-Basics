﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IPerson
{
    string Id { get; }
}
