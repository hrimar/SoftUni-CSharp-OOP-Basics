﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IRobot : IPerson
{
    string Model { get; }
   
}

