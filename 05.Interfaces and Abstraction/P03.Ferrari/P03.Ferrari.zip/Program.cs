﻿using System;

public class Program
{
    static void Main()
    {
        var name = Console.ReadLine();

        var ferrari = new Ferrari(name);

        Console.WriteLine(ferrari);

    }
}

