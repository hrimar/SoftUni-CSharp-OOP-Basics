﻿

public interface ICalling
{
    string Number { get; }

    string Calling(string number);
}
