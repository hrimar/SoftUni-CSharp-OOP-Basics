﻿public interface IBrowsable
{
    string WebSite { get; }

    string Browsing(string webSite);
}
