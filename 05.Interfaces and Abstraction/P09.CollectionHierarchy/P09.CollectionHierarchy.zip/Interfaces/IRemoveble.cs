﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IRemoveble : ICollection
{
    string Remove();
}

