﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IAddable : ICollection
{
    int Add(string item);
}

