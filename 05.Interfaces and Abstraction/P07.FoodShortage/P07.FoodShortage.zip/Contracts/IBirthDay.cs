﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IBirthDay
{
    DateTime BirthDate { get; }
}

