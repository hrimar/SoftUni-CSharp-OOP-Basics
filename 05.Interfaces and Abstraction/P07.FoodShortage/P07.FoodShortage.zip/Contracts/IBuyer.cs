﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IBuyer
{
    int Food { get; }

    void BuyFood();
}

