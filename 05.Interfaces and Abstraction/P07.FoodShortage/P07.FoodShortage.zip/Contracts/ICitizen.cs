﻿using System;
using System.Collections.Generic;
using System.Text;

public interface ICitizen : IPerson, IBirthDay, IBuyer
{
    //string Id { get; }   
}

