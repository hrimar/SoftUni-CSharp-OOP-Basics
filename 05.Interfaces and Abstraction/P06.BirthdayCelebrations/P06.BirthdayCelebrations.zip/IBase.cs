﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IBase
{
    string Name { get; }
}
