﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IRobot : IBase
{
    string Id { get; }

}

