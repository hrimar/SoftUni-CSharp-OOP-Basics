﻿
using System;

public interface IPet : IBase, IBirthDay
{    
   
}

