﻿namespace Forum.Models
{
    public interface IIdentifiable
    {
        int Id { get; set; }
    }
}