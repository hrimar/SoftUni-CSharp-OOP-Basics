﻿using System;

class Program
{
    static void Main()
    {
       // var stack = new StackOfStrings();

        // test:
        //stack.Push("first");
        //stack.Push("second");
        //stack.Pop();

        //Console.WriteLine(string.Join(", " , stack.Data));
    }
}

