﻿using System;

   class Program
    {
        static void Main()
        {
        Puppy puppy = new Puppy();
        puppy.Eat();
        puppy.Bark();
        puppy.Weep();
        }
    }

