﻿using System;
using System.Collections.Generic;
using System.Text;

public class OtherFood : Food
{
    public OtherFood()
    : base(-1)
    {
    }
}
