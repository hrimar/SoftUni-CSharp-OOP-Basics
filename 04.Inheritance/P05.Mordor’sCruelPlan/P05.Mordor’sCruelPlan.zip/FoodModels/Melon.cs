﻿using System;
using System.Collections.Generic;
using System.Text;

public class Melon : Food
{
    public Melon()
        : base(1)
    {
    }
}
