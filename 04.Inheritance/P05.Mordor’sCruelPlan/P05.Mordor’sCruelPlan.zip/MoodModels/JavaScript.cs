﻿using System;
using System.Collections.Generic;
using System.Text;

public class JavaScript : Mood
    {
    }

