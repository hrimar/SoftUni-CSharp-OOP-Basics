﻿using System;


class Program
{
    static void Main()
    {
        //StudentSystem studentSystem = new StudentSystem();
        //while (true)
        //{
        //    studentSystem.ParseCommand();
        //}

        var studentSystem = new StudentSystem();
        string command; 
        while ((command = Console.ReadLine()) != "Exit")
        {
            studentSystem.ParseCommand(command, Console.WriteLine); // !!!!
        }
    }
}

