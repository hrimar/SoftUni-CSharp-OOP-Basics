﻿public enum Seasons
{
    Autumn = 1,
    Spring,      // 2
    Winter,
    Summer
}