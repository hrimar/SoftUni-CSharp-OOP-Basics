﻿using System;
using System.Collections.Generic;
using System.Text;

public class Owl : Bird
{        
    public Owl(string name, double weight, double windSize)
    {
        this.Name = name;   // this или base,  за да бземем от абстраkт класа?
        base.Weight = weight;
        base.WingSize = windSize;
        base.FoodEaten = 0;

    }

    public override string AskForFood()
    {
        return "Hoot Hoot";
    }

    public override void Eating(int quantity)
    {
        this.FoodEaten += quantity;
        this.Weight += quantity* 0.25;
    }

 
    public override string ToString()
    {
        return base.ToString()+$"[{this.Name}, {WingSize}, {this.Weight}, {this.FoodEaten}]";
    }
}

