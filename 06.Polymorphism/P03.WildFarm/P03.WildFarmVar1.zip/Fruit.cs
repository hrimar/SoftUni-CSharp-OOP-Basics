﻿using System;
using System.Collections.Generic;
using System.Text;

public class Fruit : Food
    {
    // помисли  да вкараш тип ахрана да е класа не стринг!!!
    }

