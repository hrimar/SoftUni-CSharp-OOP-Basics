﻿using System;
using System.Collections.Generic;
using System.Text;

public class Cat : Feline
{
    public Cat(string name, double weight, string livingRegion, string breed)
    {
        this.Name = name;
        this.Weight = weight;
        base.LivingRegion = livingRegion;
        this.Breed = breed;
        base.FoodEaten = 0;
    }

    public override string AskForFood()
    {
        return "Meow";
    }

    public override void Eating(int quantity)
    {
        this.FoodEaten += quantity;
        this.Weight += quantity*0.3;
    }

    public override string ToString()
    {
        return base.ToString() + $"[{this.Name}, {this.Breed}, {this.Weight}, {this.LivingRegion}, {this.FoodEaten}]";
    }
}

