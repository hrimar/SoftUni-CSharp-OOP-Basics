﻿using System;
using System.Collections.Generic;
using System.Text;

public class Mouse : Mammal
{
    public Mouse(string name, double weight, string livingRegion)
    {
        this.Name = name;
        this.Weight = weight;
        base.LivingRegion = livingRegion;
        base.FoodEaten = 0;
    }

    public override string AskForFood()
    {
        return "Squeak";
    }

    public override void Eating(int quantity)
    {
        this.FoodEaten += quantity;
        this.Weight += quantity * 0.1;
    }

    public override string ToString()
    {
        return base.ToString() + $"[{this.Name}, {this.Weight}, {this.LivingRegion}, {this.FoodEaten}]";
    }
}

