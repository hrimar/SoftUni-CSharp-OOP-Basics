﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        //1. помисли  да вкараш тип ахрана да е класа не стринг!!!
        //2.  // this или base,  за да бземем от абстраkт класа?

        var animals = new List<Animal>();

        string input;
        while ((input = Console.ReadLine()) != "End")
        {
            var inputDetails = input.Split();
            var foodDetails = Console.ReadLine().Split();
            var foodType = foodDetails[0];
            int foodQuantity = int.Parse(foodDetails[1]);
            var animalType = inputDetails[0];
            var animalName = inputDetails[1];
            double weight;
            string region;
            string breed;
            double wingSize;

            switch (animalType)
            {
                case "Mouse":
                    weight = double.Parse(inputDetails[2]);
                    region = inputDetails[3];
                    Animal mouse = new Mouse(animalName, weight, region);
                    animals.Add(mouse);
                    Console.WriteLine(mouse.AskForFood());
                    if (foodType == "Vegetable" || foodType == "Fruit")
                    {
                        mouse.Eating(foodQuantity);
                    }
                    else
                    {
                        Console.WriteLine($"{animalType} does not eat {foodType}!");
                    }
                    break;
                case "Dog":
                    weight = double.Parse(inputDetails[2]);
                    region = inputDetails[3];
                    Animal dog = new Dog(animalName, weight, region);
                    animals.Add(dog);
                    Console.WriteLine(dog.AskForFood());
                    if (foodType == "Meat")
                    {
                        dog.Eating(foodQuantity);
                    }
                    else
                    {
                        Console.WriteLine($"{animalType} does not eat {foodType}!");
                    }
                    break;
                case "Cat":
                    weight = double.Parse(inputDetails[2]);
                    region = inputDetails[3];
                    breed = inputDetails[4];
                    Animal cat = new Cat(animalName, weight, region, breed);
                    animals.Add(cat);
                    Console.WriteLine(cat.AskForFood());
                    if (foodType == "Vegetable" || foodType == "Meat")
                    {
                        cat.Eating(foodQuantity);
                    }
                    else
                    {
                        Console.WriteLine($"{animalType} does not eat {foodType}!");
                    }
                    break;
                case "Tiger":
                    weight = double.Parse(inputDetails[2]);
                    region = inputDetails[3];
                   breed = inputDetails[4];
                    Animal tiger = new Tiger(animalName, weight, region, breed);
                    animals.Add(tiger);
                    Console.WriteLine(tiger.AskForFood());
                    if (foodType == "Meat")
                    {
                        tiger.Eating(foodQuantity);
                    }
                    else
                    {
                        Console.WriteLine($"{animalType} does not eat {foodType}!");
                    }
                    break;
                case "Owl":
                    weight = double.Parse(inputDetails[2]);
                    wingSize = double.Parse(inputDetails[3]);
                    Animal owl = new Owl(animalName, weight, wingSize);
                    animals.Add(owl);
                    Console.WriteLine(owl.AskForFood());
                    //if (foodType == "Vegetable" || foodType == "Fruit")
                    //{
                       owl.Eating(foodQuantity);
                    //}
                    //else
                    //{
                     //   Console.WriteLine($"{animalType} does not eat {foodType}!");
                    //}
                    break;
                case "Hen":
                    weight = double.Parse(inputDetails[2]);
                    wingSize = double.Parse(inputDetails[3]);
                    Animal hen = new Hen(animalName, weight, wingSize);
                    animals.Add(hen);
                    Console.WriteLine(hen.AskForFood());
                    //if (foodType == "Vegetable" || foodType == "Fruit")
                    //{
                    hen.Eating(foodQuantity);
                    //}
                    //else
                    //{
                    //   Console.WriteLine($"{animalType} does not eat {foodType}!");
                    //}
                    break;
            }

           
        }
        foreach (var animal in animals)
        {
            Console.WriteLine(animal.ToString());
        }
    }
}

