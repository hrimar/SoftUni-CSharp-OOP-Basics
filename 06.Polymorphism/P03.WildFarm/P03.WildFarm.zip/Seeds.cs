﻿
public class Seeds : Food
{
    public Seeds(int quantity) : base(quantity)
    {
       // this.Quantity = quantity;
    }
}

