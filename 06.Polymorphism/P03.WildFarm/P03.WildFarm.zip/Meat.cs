﻿using System;
using System.Collections.Generic;
using System.Text;

public class Meat : Food
{
    public Meat(int quantity) : base(quantity)
    {
        //this.Quantity = quantity;
    }
}

