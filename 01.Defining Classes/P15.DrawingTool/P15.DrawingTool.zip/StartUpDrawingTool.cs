﻿using System;


class StartUpDrawingTool
{
    static void Main()
    {
        var input = Console.ReadLine();

        var drawingTool = new DrawingTool(input);
    

        
        
    }
}

