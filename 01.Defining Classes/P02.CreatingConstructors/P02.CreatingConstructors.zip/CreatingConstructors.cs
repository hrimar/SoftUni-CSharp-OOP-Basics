﻿using System;

class CreatingConstructors
{
    static void Main()
    {

    }
}
