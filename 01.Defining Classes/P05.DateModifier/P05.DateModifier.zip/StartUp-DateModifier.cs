﻿using System;
using System.Globalization;

class StartUpDateModifier
{
    static void Main()
    {

        string startDate = Console.ReadLine();
        
        var endDate = Console.ReadLine();
      
        
        var dif = new DateModifier();
        var result =dif.CalcDiference(startDate, endDate);

        Console.WriteLine(result);
    }
}

