﻿using System;
using System.Collections.Generic;
using System.Text;

public class Cargo
{
    public int cargoWeight;
    public string cargoType;

    public Cargo(int cargoWeight, string cargoType)
    {
        this.cargoWeight = cargoWeight;
        this.cargoType = cargoType;
    }
}

