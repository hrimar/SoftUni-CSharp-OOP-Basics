﻿
namespace BashSoft
{
    class Launcher
    {
        static void Main()
        {
            // IOManager.TraverseDirectory(@"C:\Users\Lenovo\source\repos\BashSoft\BashSoft");
            //StudentRepository.InitializeData();
            //StudentRepository.GetAllStudentsFromCourse("Unity");
            // Judge.Tester.CompareContent(@"C:\Users\Lenovo\Desktop\BashSoft-Resources\test1.txt", @"C:\Users\Lenovo\Desktop\BashSoft-Resources\test3.txt");
            //IOManager.CreateDirectoryInCurrentFolder("pesho");
            InputReader.StartReadingCommands();
        }
    }
}
