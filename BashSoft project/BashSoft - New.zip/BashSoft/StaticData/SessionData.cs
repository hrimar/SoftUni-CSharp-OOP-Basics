﻿using System;
using System.IO;

namespace BashSoft.StaticData
{
   public static class SessionData
    {
        public static string currentPath = Directory.GetCurrentDirectory();
    }
}
